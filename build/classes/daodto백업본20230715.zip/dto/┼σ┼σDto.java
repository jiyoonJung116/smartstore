package dto;

public class 톡톡Dto {
	private String sellerId;	//판매자ID
	private String senderId;	//발신자ID
	private String talkContent;	//톡톡내용
	private long pnumber; //상품번호
	private String pname;  //상품명
	private int price; //상품가격
	private String customer_id; //구매자 id
	private boolean readStatus; // 1 : true, 0 : false
	private String talkTime;  // date --> String
	
//	public 톡톡Dto(String sellerId, String senderId, String talkContent, long pnumber, String pname, int price,
//			String customer_id) {
//		this.sellerId = sellerId;
//		this.senderId = senderId;
//		this.talkContent = talkContent;
//		this.pnumber = pnumber;
//		this.pname = pname;
//		this.price = price;
//		this.customer_id = customer_id;
//	}

	public 톡톡Dto(String sellerId, String senderId, String talkContent, long pnumber, String pname, int price, String customer_id, boolean readStatus, String talkTime) {
		this.sellerId = sellerId;
		this.senderId = senderId;
		this.talkContent = talkContent;
		this.pnumber = pnumber;
		this.pname = pname;
		this.price = price;
		this.customer_id = customer_id;
		this.readStatus = readStatus;
		this.talkTime = talkTime;
	}

	public String getSellerId() {
		return sellerId;
	}

	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}

	public String getSenderId() {
		return senderId;
	}

	public void setSenderId(String senderId) {
		this.senderId = senderId;
	}

	public String getTalkContent() {
		return talkContent;
	}

	public void setTalkContent(String talkContent) {
		this.talkContent = talkContent;
	}

	public long getPnumber() {
		return pnumber;
	}

	public void setPnumber(long pnumber) {
		this.pnumber = pnumber;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}

	public boolean isReadStatus() {
		return readStatus;
	}

	public void setReadStatus(boolean readStatus) {
		this.readStatus = readStatus;
	}

	public String getTalkTime() {
		return talkTime;
	}

	public void setTalkTime(String talkTime) {
		this.talkTime = talkTime;
	}
	
	
}
