package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import dto.톡톡Dto;

public class TalkTalkChatContentDao {
	public ArrayList<톡톡Dto> chatContent(int num) {
		Connection conn = Jdbc.connect();
		ArrayList<톡톡Dto> listchat = new ArrayList<톡톡Dto>();

		String sql = "SELECT tc.seller_id, tc.sender_id,tc.talk_content, tt.pnumber, p.pname, p.price, tt.customer_id, tc.talk_time, tc.read_status" + 
				" FROM talktalk_content tc,talktalk_list tt , product p" + 
				" WHERE tc.talk_num = tt.talk_num" + 
				" AND p.pnumber = tt.pnumber" + 
				" AND tc.talk_num=?";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				String sellerId = rs.getString("seller_id");
				String senderId = rs.getString("sender_id");
				String talkContent = rs.getString("talk_content");
				long pnumber = rs.getLong("pnumber");
				String pname = rs.getString("pname");
				int price = rs.getInt("price");
				String customer_id = rs.getString("customer_id");
				boolean readStatus = rs.getInt("read_status")==1;
				String talkTime = rs.getString("talk_time");
				톡톡Dto dto = new 톡톡Dto(sellerId, senderId, talkContent, pnumber, pname, price, customer_id, readStatus, talkTime);
				listchat.add(dto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return listchat;
	}
	
	public String getCustomerIdFromRoomNumber(int num) {
		Connection conn = Jdbc.connect();

		String sql = "SELECT customer_id" + 
				" FROM talktalk_list" + 
				" WHERE talk_num = ?";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String customer_id = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				customer_id = rs.getString("customer_id");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return customer_id;
	}
}
