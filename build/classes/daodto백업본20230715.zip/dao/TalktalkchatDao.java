package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class TalktalkchatDao {
	public void chat(String sellerId, String customerId, String senderId, String chat, int num) {
		Connection conn = Jdbc.connect();
		String sql = "INSERT INTO talktalk_content(serial_num, seller_id, talk_num, sender_id, talk_time, read_status, talk_content) "
		                 + "VALUES (seq_talktalk_content.nextval, ?, "
		                 + "(SELECT talk_num FROM talktalk_list WHERE customer_id = ? AND seller_id = ?), "
		                 + "?, sysdate, 1, ?)";

		String sql2 = "UPDATE talktalk_list" + 
							" SET talk_final_date = sysdate" + 
							" WHERE talk_num=?"; 

		PreparedStatement pstmt = null;
		PreparedStatement pstmt2 = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, sellerId);
			pstmt.setString(2, customerId);
			pstmt.setString(3, sellerId);
			pstmt.setString(4, senderId);
			pstmt.setString(5, chat);
			pstmt.executeUpdate();

			pstmt2 = conn.prepareStatement(sql2);
			pstmt2.setInt(1, num);
			pstmt2.executeUpdate();

		    System.out.println("데이터가 성공적으로 추가되었으며, 업데이트되었습니다.");
		} catch (SQLException e) {
		    e.printStackTrace();
		} finally {
		    try {
		        if (pstmt != null) {
		        	pstmt.close();
		        }
		        if (pstmt2 != null) {
		        	pstmt2.close();
		        }
		        if (conn != null) {
		            conn.close();
		        }
		    } catch (SQLException e) {
		        e.printStackTrace();
		    }
		}


	}
}
