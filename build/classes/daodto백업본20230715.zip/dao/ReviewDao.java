package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import dto.ReviewDto;

public class ReviewDao {
	public Connection getConnection() throws Exception{
	    String driver = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String dbId = "project3";
		String dbPw = "3500";
		
		Class.forName(driver); 
		Connection conn = DriverManager.getConnection(url, dbId, dbPw);
		return conn;
	}
	public ArrayList<ReviewDto> review_select(String seller_id, String date, String date2) {
		Connection conn = Jdbc.connect();
		ArrayList<ReviewDto> review_select = new ArrayList<ReviewDto>();
		String sql = "SELECT *" + 
				" FROM review" + 
				" WHERE seller_id = ? AND review_registration_date BETWEEN TO_DATE(?, 'YYYY-MM-DD') AND TO_DATE(?, 'YYYY-MM-DD')" + 
				" ORDER BY review_num";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1,seller_id);
			pstmt.setString(2,date);
			pstmt.setString(3,date2);
			rs = pstmt.executeQuery();
			while(rs.next()) {
			Long product_order_num = rs.getLong("product_order_num");
			String review_division = rs.getString("review_division");
			int buyer_grade = rs.getInt("buyer_grade");
			String photo_video = rs.getString("photo_video");
			String review_content = rs.getString("review_content");
			Date review_registration_date2 = rs.getDate("review_registration_date");
			Date fi_modify = rs.getDate("final_modify");
			Long review_num = rs.getLong("review_num");
			String review_display_status = rs.getString("review_display_status");
			ReviewDto dto = new ReviewDto(product_order_num, review_division,buyer_grade, photo_video,
					review_content,review_registration_date2, fi_modify, review_num,review_display_status);
			review_select.add(dto);
			}
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null)
				rs.close();
				if(pstmt!=null)
				pstmt.close();
				if(conn!=null)
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return review_select;
    }
	public ArrayList<ReviewDto> review_select2(long pnumber) {
		Connection conn = Jdbc.connect();
		ArrayList<ReviewDto> review_select = new ArrayList<ReviewDto>();
		String sql = "SELECT *" + 
				" FROM review" + 
				" WHERE pnumber=?"+
				" ORDER BY review_registration_date";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setLong(1, pnumber);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				int buyer_grade = rs.getInt("buyer_grade");
				String photo_video = rs.getString("photo_video");
				String review_content = rs.getString("review_content");
				Date review_registration_date2 = rs.getDate("review_registration_date");
				Date fi_modify = rs.getDate("final_modify");
				ReviewDto dto = new ReviewDto(buyer_grade, photo_video, review_content, review_registration_date2);
				review_select.add(dto);
			}
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null)
					rs.close();
				if(pstmt!=null)
					pstmt.close();
				if(conn!=null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return review_select;
	}
}

